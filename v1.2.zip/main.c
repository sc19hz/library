#include <stdio.h>
int main() {
	while (1) {
		if (firstcase() == 1)
			break;
	}
	
	return 0;
}