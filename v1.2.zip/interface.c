#include<stdio.h>
#include"interface.h"
int checkoption(char a[10],int b) {
	int i;
	if (checknumvalid(a) == 0) {
		i = atoi(a);
		if (i > 0 && i <= b)
			return i;
		else {
			printf("Input invalid\n");
			return -1;
		}
	}
	else {
		printf("Input invalid\n");
		return -1;
	}
}
int searchcase() {
	int index = 0;
	char temp[20];
	while (1) {
		printf("Please choose an option\n");
		printf("1) Search by book title\n");
		printf("2) Search by year\n");
		printf("3) Search by author\n");
		printf("4)Quit\n");


		gets(temp);
		if (checkoption(temp, 4) != -1) {
			index = checkoption(temp, 4);
			break;
		}
		else {
			continue;
		}
	}
	while (1) {
		switch (index) {
		case 1:
		{
			findname();
			break;
		}
		case 2: {
			findyear();
			break;
		}
		case 3:
		{
			findauthor();
			break;
		}
		
		case 4:return 1;
		}
		break;
	}
	return 0;
}
void librariancase() 
{
	int index;
	char temp[20];
	while (1) 
	{
	printf("Please choose an option\n");
	printf("1) Add a book\n");
	printf("2) Remove a book\n");
	printf("3)Search for books\n");
	printf("4)Display all books\n");
	printf("5)Quit\n");
	gets(temp);
	if (checkoption(temp, 5) != -1) {
		index = checkoption(temp, 5);
	}
	else {
		continue;
	}
	
	switch (index) 
	{
	    case 1:
		{
			addbook();
			break;
		}
		case 2:
		{
			removebook();

				break;
		}
		case 3:
		{
			searchcase();
			break;
		}
		case 4: {
			show();
			break;
		}
		case 5:return 0;
		}
	}
}
int firstcase() 
{
		int index,swi;
		char temp[20];
		printf("Welcome to the library\n");
		
		while (1) {
			
			while (1) {
				printf("Please choose an option\n");
				printf("1) Register an account\n");
				printf("2) Log in\n");
				printf("3)Administrator only\n");
				printf("4)Quit\n");
				gets(temp);
				if (checkoption(temp, 4) != -1) {
					index = checkoption(temp, 4);
				}
				else {
					continue;
				}
				
				switch (index) {
				case 1:
				{
					registers();
					break;
				}
				case 2:
				{			
					int id;
					id = login();
					if (id == -1) {
						continue;
					}

					getchar();
					while (1)
					{
						printf("Please choose an option\n");
						printf("1) Borrow a book\n");
						printf("2) Return a book\n");
						printf("3) Display all books\n");
						printf("4) Quit\n");
						
						gets(temp);
						if (checkoption(temp, 4) != -1) {
							index = checkoption(temp, 4);
						}
						else {
							continue;
						}
						switch (index)
						{
						case 1:
						{
							if (searchcase() != 1) {
								printf("Please choose the book id:\n");
								scanf("%i", &index);
								borrow(id, index);
							}
							break;
						}
						case 2:
						{
							retur(id);
							break;
						}
						case 3: {
							show();
							break;}
						case 4: {
							swi = -1;
							return 0;
						}


						}

					}
				}
				case 3:
				{
					if (librarian() == 1) {
						librariancase();
					}
					break;
				}
				case 4: {
					return 1;
				}
				}
			}
		}
		if (swi == -1)
		{
			return 1;
		}
	}
		