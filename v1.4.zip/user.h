#include <stdio.h>
#ifndef USER_GUARD__H 
#define USER_GUARD__H
int showbook(struct user* u);//show all the book the user borrowed
void borrow(int id, int bid);//borrow a book
void retur(int id);//return a book

#endif