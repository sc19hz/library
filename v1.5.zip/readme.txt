welcome to the library system.
For the users to register, they will be asked to provide both username and student id. Both of them can not be same with anyone else.
Each person can only borrow at most 5 books, and can not borrow same books at one time.
The librarian password is sc19hz.
The librarian can not remove books that has been borrowed.
##################
!!!!!!Important
Before run the program, make sure the user.bin,book.bin,num.bin is ready, wether these files have content or not.