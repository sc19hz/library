#include <stdio.h>
#include"book_management.h"

int main() {
	if (load_books() == 1) {
		printf("Sorry,failed to load files,please check again\n");
		return 0;
	}
	while (1) {
		if (firstcase() == 1)
			break;
	}
	
	return 0;
}