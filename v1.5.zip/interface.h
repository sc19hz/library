#include <stdio.h>
int checkoption(char a[10], int b);//chek if the option is valid
int searchcase();//interface for book search
void librariancase();//only for the librarian
int logcase(int id);
int firstcase();