#include<stdio.h>
#include"interface.h"
int checkoption(char a[10],int b) {
	int i;
	if (checknumvalid(a) == 0) {
		i = atoi(a);
		if (i > 0 && i <= b)
			return i;
		else {
			printf("Input invalid\n");
			return -1;
		}
	}
	else {
		printf("Input invalid\n");
		return -1;
	}
}
int searchcase() {
	int index = 0,id;
	char temp[20];
	while (1) {
		printf("Please choose an option\n");
		printf("1) Search by book title\n");
		printf("2) Search by year\n");
		printf("3) Search by author\n");
		printf("4)Quit\n");


		gets(temp);
		if (checkoption(temp, 4) != -1) {
			index = checkoption(temp, 4);
			break;
		}
		else {
			continue;
		}
	}
	while (1) {
		switch (index) 
		{
		case 1:
		{
			id=find_book_by_title();
			break;
		}
		case 2: {
			id=find_book_by_year();
			break;
		}
		case 3:
		{
			id=find_book_by_author();
			break;
		}
		
		case 4:return 1;
		}
		break;
	}
	if (id == 1)
		return 2;
	return 0;
}
void librariancase() 
{
	int index;
	char temp[20];//buffer
	while (1) 
	{
	printf("Administrator mode\n");
	printf("Please choose an option\n");
	printf("1) Add a book\n");
	printf("2) Remove a book\n");
	printf("3)Search for books\n");
	printf("4)Display all books\n");
	printf("5)Quit\n");
	gets(temp);
	if (checkoption(temp, 5) != -1) {
		index = checkoption(temp, 5);
	}
	else {
		continue;
	}
	
	switch (index) 
	{
	    case 1:
		{
			add_book();
			break;
		}
		case 2:
		{
			remove_book();

				break;
		}
		case 3:
		{
			searchcase();
			break;
		}
		case 4: {
			show();
			break;
		}
		case 5:return 0;
		}
	}
}
int logcase(int id)
{
	char temp[20];
	int index,swi;
	while (1)
	{
		printf("Please choose an option\n");
		printf("1) Borrow a book\n");
		printf("2) Return a book\n");
		printf("3) Display all books\n");
		printf("4) Log out\n");

		gets(temp);
		if (checkoption(temp, 4) != -1) {
			index = checkoption(temp, 4);
		}
		else {
			continue;
		}
		switch (index)
		{
		case 1:
		{
			while (1) {
				swi = searchcase();
				if (swi ==0) {
					printf("Please choose the book id:\n");
					scanf("%i", &index);
					borrow(id, index);
					break;
				}
				else
				{
					if (swi == 1) {
						break;
					}
				}
			}
			
			break;
		}
		case 2:
		{
			retur(id);
			break;
		}
		case 3: {
			show();
			break;
		}
		case 4: {
			printf("Logging out...\n");
			return -1;
		}


		}

	}
}
int firstcase() 
{
		int index,swi;
		char temp[20];
		printf("Welcome to the library\n");
		
		while (1) {
			
			while (1) {
				printf("Please choose an option\n");
				printf("1) Register an account\n");
				printf("2) Log in\n");
				printf("3)Administrator only\n");
				printf("4)Quit\n");
				gets(temp);
				if (checkoption(temp, 4) != -1) {
					index = checkoption(temp, 4);
				}
				else {
					continue;
				}
				
				switch (index) {
				case 1:
				{
					registers();
					break;
				}
				case 2:
				{			
					int id;
					id = login();
					if (id == -1) {
						continue;
					}

					getchar();
					if (logcase(id) == -1)
						swi = -1;//log out
					break;
					
				}
				case 3:
				{
					if (librarian() == 1) {
						librariancase();
					}
					break;
				}
				case 4: {
					return 1;
				}
				}
			}
		}
		if (swi == -1)
		{
			return 1;//the user do not want to log in.
		}
	}
		