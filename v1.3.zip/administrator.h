#include <stdio.h>
int checknumvalid(char temp[20]);//check if the string is all numbers
int checkcharvalid(char temp[100]);//check if the string is all words
void showone(struct _Book a);//show one book
void firstrow();//the head of the table
void showone(struct _Book a);//show the ditail of the specific book
void show();//show all books
int librarian();//check the librarian password
int compare(char name1[20], char name2[5][20], int nu);//find if the author name provided matches the book stored.