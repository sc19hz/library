#include <stdio.h>
typedef struct user
{
    char uname[11]; //student name (can not be repeated)
    char password[20]; //
    unsigned int sid;//student id(can not be repeated)
    int numbor;//number of books borrowed
    int borbook[5];//the array of ids of the books

}users;
int showbook(struct user* u);//show all the book the user borrowed
void borrow(int id,int bid);//borrow a book
void retur(int id);//return a book
void clear(struct user* u);//initialize the borrowed books
void registers();//register
int login();//login