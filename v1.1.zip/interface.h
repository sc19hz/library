#include <stdio.h>
int searchcase();
void librariancase();
int firstcase();